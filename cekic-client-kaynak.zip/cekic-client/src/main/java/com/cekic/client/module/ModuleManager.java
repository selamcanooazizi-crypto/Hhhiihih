package com.cekic.client.module;

import java.util.List;

public final class ModuleManager {
    public static final TriggerBot TRIGGER_BOT = new TriggerBot();
    public static final AimAssist AIM_ASSIST = new AimAssist();
    public static final ElytraTarget ELYTRA_TARGET = new ElytraTarget();

    private static final List<Module> ALL = List.of(TRIGGER_BOT, AIM_ASSIST, ELYTRA_TARGET);

    private ModuleManager() {}

    public static List<Module> all() {
        return ALL;
    }
}
