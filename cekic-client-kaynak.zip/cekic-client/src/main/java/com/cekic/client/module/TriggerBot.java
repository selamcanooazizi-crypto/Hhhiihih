package com.cekic.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * Nişangâh bir oyuncunun üzerindeyken vurur, ama sürekli değil:
 * hedefin üzerindeki kırmızı hasar efekti (hurtTime) bitmeden vurmaz.
 * Efekt bitince tekrar vurur.
 */
public class TriggerBot extends Module {
    public TriggerBot() {
        super("Trigger Bot");
    }

    @Override
    public boolean isRunning() {
        return isEnabled() || ModuleManager.ELYTRA_TARGET.isAttacking();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!isRunning()) return;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return;

        Entity entity = entityHit.getEntity();
        if (!(entity instanceof PlayerEntity)) return;
        PlayerEntity target = (PlayerEntity) entity;
        if (!target.isAlive() || target.isSpectator()) return;

        // Kırmızı hasar efekti hâlâ sürüyorsa vurma.
        if (target.hurtTime > 0) return;

        // Silah tam şarj olmadan vurma (tam hasar için).
        if (mc.player.getAttackCooldownProgress(0.5f) < 0.95f) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
