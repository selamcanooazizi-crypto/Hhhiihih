package com.cekic.client.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    private boolean enabled;

    protected Module(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Modülün şu an çalışıp çalışmadığı (başka bir modül tarafından da tetiklenebilir). */
    public boolean isRunning() {
        return enabled;
    }

    protected void onEnable() {}

    protected void onDisable() {}

    /** Her oyun tick'inde (saniyede 20 kez) çağrılır. */
    public void onTick(MinecraftClient mc) {}

    /** Her karede çağrılır; akıcı kamera hareketi için. */
    public void onRender(MinecraftClient mc, float tickDelta, float dt) {}
}
