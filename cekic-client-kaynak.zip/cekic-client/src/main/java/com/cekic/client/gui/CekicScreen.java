package com.cekic.client.gui;

import com.cekic.client.CekicClient;
import com.cekic.client.module.ElytraTarget;
import com.cekic.client.module.Module;
import com.cekic.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class CekicScreen extends Screen {
    private final long openedAt = System.currentTimeMillis();
    private int titleY;

    public CekicScreen() {
        super(Text.literal(CekicClient.NAME));
    }

    @Override
    protected void init() {
        int w = 200;
        int x = width / 2 - w / 2;
        int y = height / 2 - 62;
        titleY = y - 22;

        for (Module module : ModuleManager.all()) {
            addDrawableChild(ButtonWidget.builder(label(module), b -> {
                module.toggle();
                b.setMessage(label(module));
            }).dimensions(x, y, w, 20).build());
            y += 24;

            if (module instanceof ElytraTarget elytra) {
                ButtonWidget delayLabel = ButtonWidget.builder(delayText(elytra), b -> {})
                        .dimensions(x + 24, y, w - 48, 20).build();
                delayLabel.active = false;

                addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
                    elytra.setDelayMs(elytra.getDelayMs() - 50);
                    delayLabel.setMessage(delayText(elytra));
                }).dimensions(x, y, 20, 20).build());
                addDrawableChild(delayLabel);
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
                    elytra.setDelayMs(elytra.getDelayMs() + 50);
                    delayLabel.setMessage(delayText(elytra));
                }).dimensions(x + w - 20, y, 20, 20).build());
                y += 24;

                addDrawableChild(ButtonWidget.builder(rocketText(elytra), b -> {
                    elytra.setUseRocket(!elytra.isUseRocket());
                    b.setMessage(rocketText(elytra));
                }).dimensions(x, y, w, 20).build());
                y += 24;
            }
        }
    }

    private static Text label(Module module) {
        boolean on = module.isEnabled();
        return Text.literal(module.name + ": ")
                .append(Text.literal(on ? "AÇIK" : "KAPALI").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    private static Text delayText(ElytraTarget elytra) {
        return Text.literal("Delay: " + elytra.getDelayMs() + " ms");
    }

    private static Text rocketText(ElytraTarget elytra) {
        boolean on = elytra.isUseRocket();
        return Text.literal("Fişek Kullan: ")
                .append(Text.literal(on ? "AÇIK" : "KAPALI").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    /** Menü açıkken de Sağ Shift'e iki kez basınca kapanır (bırakma anı sayılır, basılı tutmak sorun çıkarmaz). */
    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT
                && System.currentTimeMillis() - openedAt > 400
                && CekicClient.registerPress()) {
            close();
            return true;
        }
        return super.keyReleased(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(CekicClient.NAME).formatted(Formatting.GOLD, Formatting.BOLD),
                width / 2, titleY, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
}
